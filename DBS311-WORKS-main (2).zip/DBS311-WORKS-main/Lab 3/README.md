# This week's topics:
## Sub-Queries 
-> Nested queries 
