# This week's topics:
## Single Line Functions
-> Numeric/ Char/ Date<br>
-> Functions
