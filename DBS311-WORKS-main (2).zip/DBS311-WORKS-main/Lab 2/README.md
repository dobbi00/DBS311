# This week's topics:
## Single/Multi Row Functions
-> Count<br>
-> Sum<br>
-> AVG<br>
-> Max<br>
-> Min<br>
