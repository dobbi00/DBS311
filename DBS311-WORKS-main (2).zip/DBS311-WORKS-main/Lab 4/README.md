# This week's topics:
## Set Operators Union
-> Union all<br>
-> Intersect<br>
-> Minus
